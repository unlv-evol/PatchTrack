package main

import (
	"fmt"
	"strings"
)

// trimString removes leading spaces from each line in a multiline string
func trimString(s string) string {
	lines := strings.Split(s, "\n")
	for i, line := range lines {
		lines[i] = strings.TrimLeft(line, " \t")
	}
	return strings.Join(lines, "\n")
}

func main() {
	fmt.Println("Hello, 世界")

	// Multiline string with leading spaces
	rawString := trimString(`
		abc
		def
		123
		456
	`)

	fmt.Println(rawString)
}