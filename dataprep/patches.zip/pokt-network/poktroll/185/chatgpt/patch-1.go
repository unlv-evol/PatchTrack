package main

import (
	"fmt"
	"strings"
)

func main() {
	fmt.Println("Hello, 世界")

	// Multiline string with leading spaces for readability
	rawString := `
		abc
		def
		123
		456
	`

	// Split the string into lines
	lines := strings.Split(rawString, "\n")

	// Trim leading spaces from each line
	for i, line := range lines {
		lines[i] = strings.TrimLeft(line, " \t")
	}

	// Join the lines back into a single string
	cleanString := strings.Join(lines, "\n")

	fmt.Println(cleanString)
}