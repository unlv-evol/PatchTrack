ffmpeg -i "concat:file1.mp3|file2.mp3|file3.mp3" -acodec copy output.mp3
