handleWatchFileChanges(filePath, encoding) {
  try {
    fs.watch(filePath, eventType => {
      if (eventType === "change") {
        console.log("File changed");
        this.handleLoad(filePath, encoding); // `encoding`を追加
      }
    });
  } catch (error) {
    this.Err.errorMain(error);
  }
}
