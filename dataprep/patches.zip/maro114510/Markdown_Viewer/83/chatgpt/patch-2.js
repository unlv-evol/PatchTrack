async handleMain() {
  try {
    this.watchFilesPath.push(await this.handleGetFilePath());
    const encoding = await this.handleGetFileEncoding(this.watchFilesPath[0]); // `encoding`を取得
    const fileContent = await this.handleGetFileContent(this.watchFilesPath[0], encoding);
    const html = this.handleMarkdown(fileContent);
    this.handleInsertHTML(html);

    this.handleWatchFileChanges(this.watchFilesPath[0], encoding); // `encoding`を渡す
  } catch (error) {
    this.Err.errorMain(error);
  }
}
