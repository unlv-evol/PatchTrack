handleWatchFileChanges(filePath) {
  try {
    let isWatching = true; // 監視フラグを追加

    fs.watch(filePath, eventType => {
      if (eventType === "change" && isWatching) { // 監視フラグが有効な場合のみ処理を実行
        isWatching = false; // 監視フラグを無効化
        console.log("File changed");
        this.handleLoad(filePath, "utf8");
        setTimeout(() => {
          isWatching = true; // 一定時間後に監視フラグを再度有効化
        }, 1000); // 1秒後に再度監視フラグを有効化する例
      }
    });
  } catch (error) {
    this.Err.errorMain(error);
  }
}
