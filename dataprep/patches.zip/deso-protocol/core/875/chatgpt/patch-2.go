go func() {
  for {
    X = NewMyStruct() // Update pointer X to a new instance
  }
}()

go func() {
  tempX = X // Copy X to tempX
  // Print something based on tempX
}()