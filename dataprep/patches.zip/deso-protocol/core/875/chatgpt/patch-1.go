import (
    "sync"
)

var (
    X    *MyStruct
    lock sync.Mutex
)

// Goroutine for updating X
go func() {
    for {
        lock.Lock()
        X = NewMyStruct()
        lock.Unlock()
    }
}()

// Goroutine for reading X
go func() {
    for {
        lock.Lock()
        tempX := X
        lock.Unlock()
        // Print something based on tempX
    }
}()