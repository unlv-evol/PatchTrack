git commit --amend
