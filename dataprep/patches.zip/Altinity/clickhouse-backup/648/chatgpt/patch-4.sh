git add <file1> <file2> ...  # Stage the modified files
git rm <file3> <file4> ...   # Remove any files you want to delete
