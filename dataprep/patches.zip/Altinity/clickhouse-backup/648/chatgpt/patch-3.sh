git rebase -i origin/master
