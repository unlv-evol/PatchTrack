git checkout <your-branch>
