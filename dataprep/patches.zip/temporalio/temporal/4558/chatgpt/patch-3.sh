#!/bin/bash

set -ex

# Change directory to your codebase root folder
cd /path/to/your/codebase

# Find all Go files with camel case names
files=$(find . -type f -name "*.go" | grep -E '.*\/[a-z]+[A-Z]+.*')

# Loop through each file and rename it
for file in $files; do
  # Get the file's directory and base name
  dir=$(dirname "$file")
  base=$(basename "$file")

  # Convert camel case to snake case
  snake_case=$(echo "$base" | sed -E 's/([^A-Z])([A-Z])/\1_\2/g' | tr '[:upper:]' '[:lower:]')

  # Construct the new file name
  new_name="$dir/$(dirname "$base")_$snake_case"

  # Rename the file
  mv "$file" "$new_name"

  echo "Renamed $file to $new_name"
done
