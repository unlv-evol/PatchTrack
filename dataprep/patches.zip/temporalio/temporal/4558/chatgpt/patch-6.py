import os
import re

# Change directory to your codebase root folder
os.chdir('/path/to/your/codebase')

# Regex pattern to match camel case file names
pattern = re.compile(r'.*/([a-z]+[A-Z]+.*)\.go$')

# Loop through each file in the directory and its subdirectories
for root, dirs, files in os.walk('.'):
    for file in files:
        # Check if the file is a Go file with camel case name
        match = pattern.match(os.path.join(root, file))
        if match:
            old_name = match.group(1)
            new_name = re.sub(r'([a-z])([A-Z])', r'\1_\2', old_name).lower() + '.go'
            new_path = os.path.join(root, new_name)

            # Rename the file
            os.rename(os.path.join(root, file), new_path)
            print(f"Renamed {os.path.join(root, file)} to {new_path}")
