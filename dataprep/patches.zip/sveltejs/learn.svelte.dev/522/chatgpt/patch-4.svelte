<svg
    role="img"
    aria-label="Pointer" <!-- Provide a meaningful description -->
    on:mousemove={(e) => {
        coords.set({ x: e.clientX, y: e.clientY });
    }}
    on:mousedown={() => size.set(30)}
    on:mouseup={() => size.set(10)}
>
    <circle
        cx={$coords.x}
        cy={$coords.y}
        r={$size}
    />
</svg>