# spec/your_fix_spec.rb

require 'rails_helper'

RSpec.describe "Filtering sensitive parameters in logs" do
  it "filters out secret values from logs" do
    # Mocking a controller action with sensitive parameters
    params = { 
      passw: "password",
      secret: "secret_value",
      token: "access_token",
      _key: "api_key",
      crypt: "encrypted_value",
      salt: "salt_value",
      certificate: "certificate_data",
      otp: "123456",
      ssn: "123-45-6789"
    }
    
    controller = ApplicationController.new
    allow(controller).to receive(:params).and_return(params)
    
    # Trigger the action that logs the parameters
    controller.action_that_logs_parameters
    
    # Fetch the logs
    logs = Rails.logger.instance_variable_get(:@logdev).dev.string
    
    # Ensure that the sensitive parameters are filtered in logs
    expect(logs).not_to include("password")
    expect(logs).not_to include("secret_value")
    expect(logs).not_to include("access_token")
    expect(logs).not_to include("api_key")
    expect(logs).not_to include("encrypted_value")
    expect(logs).not_to include("salt_value")
    expect(logs).not_to include("certificate_data")
    expect(logs).not_to include("123456")
    expect(logs).not_to include("123-45-6789")
  end
end
