aws --profile localstack s3 mb s3://my-local-bucket
