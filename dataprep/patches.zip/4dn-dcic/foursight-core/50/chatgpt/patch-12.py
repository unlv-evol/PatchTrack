import boto3

# Configure the endpoint URLs for different services
s3_endpoint_url = 'http://localhost:4572'
sqs_endpoint_url = 'http://localhost:4576'

# Set up separate sessions for different services
s3_session = boto3.Session(region_name='us-east-1')
sqs_session = boto3.Session(region_name='us-east-1')

# Create S3 client and resource with the custom endpoint URL
s3_client = s3_session.client('s3', endpoint_url=s3_endpoint_url)
s3_resource = s3_session.resource('s3', endpoint_url=s3_endpoint_url)

# Create SQS client and resource with the custom endpoint URL
sqs_client = sqs_session.client('sqs', endpoint_url=sqs_endpoint_url)
sqs_resource = sqs_session.resource('sqs', endpoint_url=sqs_endpoint_url)

# Use the S3 and SQS clients and resources with the custom endpoint URLs
s3_client.list_buckets()
sqs_client.list_queues()
