aws s3 cp /path/to/local/file s3://my-bucket-name --endpoint-url http://localhost:4572
