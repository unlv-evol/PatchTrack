import boto3

# Configure the endpoint URL for LocalStack SQS
endpoint_url = 'http://localhost:4566'

# Create the SQS client
sqs_client = boto3.client('sqs', endpoint_url=endpoint_url)

# Use the SQS client with LocalStack
queue_name = 'my-local-queue'

# Create an SQS queue
response = sqs_client.create_queue(QueueName=queue_name)
queue_url = response['QueueUrl']
print(f"Created queue with URL: {queue_url}")

# Send a message to the SQS queue
message_body = 'Hello, LocalStack SQS!'
response = sqs_client.send_message(QueueUrl=queue_url, MessageBody=message_body)
print(f"Sent message with ID: {response['MessageId']}")

# Receive messages from the SQS queue
response = sqs_client.receive_message(QueueUrl=queue_url, MaxNumberOfMessages=1)
messages = response.get('Messages', [])
for message in messages:
    print(f"Received message with ID: {message['MessageId']}, Body: {message['Body']}")

# Delete the SQS queue
sqs_client.delete_queue(QueueUrl=queue_url)
print(f"Deleted queue: {queue_url}")
