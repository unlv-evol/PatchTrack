aws --profile localstack s3 cp /path/to/local/file s3://my-local-bucket
