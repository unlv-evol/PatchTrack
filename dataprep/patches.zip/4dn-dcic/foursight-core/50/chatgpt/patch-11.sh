aws sqs receive-message --queue-url http://localhost:4566/queue/my-queue-name --endpoint-url http://localhost:4566
