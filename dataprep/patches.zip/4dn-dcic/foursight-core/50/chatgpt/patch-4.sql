Ready. Detected local AWS credentials: default
