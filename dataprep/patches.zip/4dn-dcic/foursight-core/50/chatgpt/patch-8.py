import boto3

# Configure the endpoint URL for LocalStack S3
endpoint_url = 'http://localhost:4566'

# Create the S3 client
s3_client = boto3.client('s3', endpoint_url=endpoint_url)

# Use the S3 client with LocalStack
response = s3_client.list_buckets()
print(response['Buckets'])
