CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE, -- Enforce unique emails directly
    password_hash VARCHAR(100) NOT NULL,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP, -- Removed AT TIME ZONE 'UTC' for consistency
    updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP, -- Consistency with created_at
    -- Removed UNIQUE constraint on id, as PRIMARY KEY already enforces uniqueness
    -- Removed INDEX on id, as primary keys are automatically indexed
    INDEX idx_email (email) -- Fixed syntax, ensuring indexing on email
);