UPDATE your_table_name
SET created_at = created_at AT TIME ZONE 'OriginalTimeZone' AT TIME ZONE 'NewTimeZone',
    updated_at = updated_at AT TIME ZONE 'OriginalTimeZone' AT TIME ZONE 'NewTimeZone';