CREATE TABLE contacts (
    contact_id SERIAL PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    phone_number VARCHAR(22) NOT NULL,
    user_id INTEGER NOT NULL,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    -- Removed CONSTRAINT unique_contact_id UNIQUE (contact_id), as contact_id is already a PRIMARY KEY
    CONSTRAINT fk_user_id FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE, -- Consider ON DELETE CASCADE if you want to delete contacts when a user is deleted
    INDEX idx_user_id (user_id), 
    INDEX idx_phone_number (phone_number) -- Ensured proper syntax for indexing
);