package main

import (
    "net/http"

    "github.com/go-chi/chi"
)

func main() {
    r := chi.NewRouter()

    // Define your routes
    r.Get("/", func(w http.ResponseWriter, r *http.Request) {
        // Assume some condition that checks for invalid request
        invalid := true
        if invalid {
            http.Error(w, http.StatusText(http.StatusBadRequest), http.StatusBadRequest)
            return
        }

        // Your logic for valid request
        w.Write([]byte("Hello, World!"))
    })

    http.ListenAndServe(":8080", r)
}