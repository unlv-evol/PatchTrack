'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('UserDepartments', { // nombre de la tabla de unión
      userId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'Users', // nombre de la tabla de usuarios
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      departmentId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
          model: 'Departments', // nombre de la tabla de departamentos
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });

    // Opcional: Agregar clave primaria compuesta si es necesario
    await queryInterface.addConstraint('UserDepartments', {
      fields: ['userId', 'departmentId'],
      type: 'primary key',
      name: 'pk_user_departments' // Nombre de la clave primaria
    });
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('UserDepartments');
  }
};