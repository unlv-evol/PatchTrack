// 通常のHTMLの<a>タグを使用する例
<a href="https://example.com">External Link</a>

// passHref属性を使用する例
import { Button } from 'semantic-ui-react';
import Link from 'next/link';    

const Example = () => (
  <Link href="https://example.com" passHref={true}>
    <Button>External Link</Button>
  </Link>
)

export default Example;
