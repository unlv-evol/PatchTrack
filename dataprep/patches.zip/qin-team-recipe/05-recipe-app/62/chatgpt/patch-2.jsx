// カスタムのLinkコンポーネント
import Link from 'next/link'; 

const SmartLink = ({link, url}) => {
  const regEx = /^http/;

  return regEx.test(url) ? <a href={url}>{link}</a> : <Link href={url}>{link}</Link>;
}

export default SmartLink;

// コンポーネントの使用例
import SmartLink from 'path/to/SmartLink'; // 正しいパスを設定する

// レンダリングメソッドの中で
// 以下はHTMLのAタグを使用します
<SmartLink href="https://example.com" link="External Link" />
// 以下はNext.jsのLinkコンポーネントを使用します
<SmartLink href="/internal-page" link="Internal Link" />
