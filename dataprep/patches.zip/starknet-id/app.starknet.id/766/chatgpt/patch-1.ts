type CopyContentProps = {
  value?: string;
  className?: string;
};