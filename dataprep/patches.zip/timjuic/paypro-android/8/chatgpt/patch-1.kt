import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.material3.icons.Icons
import androidx.compose.material3.icons.filled.Done
import androidx.compose.material3.icons.filled.Close
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.KeyboardType
import com.example.featherandroidtasks.ui.theme.FeatherAndroidTasksTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FeatherAndroidTasksTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.White
                ) {
                    // Display your content
                    AppContent()
                }
            }
        }
    }
}

@Composable
fun AppContent() {
    var isDialogVisible by remember { mutableStateOf(false) }
    var textValue by remember { mutableStateOf("Initial Value") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Button(onClick = { isDialogVisible = true }) {
            Text(text = "Show Modal")
        }

        // Modal Dialog
        if (isDialogVisible) {
            Dialog(
                onDismissRequest = {
                    // Handle dismissal, if needed
                    isDialogVisible = false
                },
                content = {
                    var keyboardController by remember { mutableStateOf<SoftwareKeyboardController?>(null) }

                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth()
                            .heightIn(min = 200.dp)
                    ) {
                        // Dialog content
                        BasicTextField(
                            value = textValue,
                            onValueChange = {
                                textValue = it
                            },
                            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Text),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                                .onGloballyPositioned {
                                    // Automatically show the keyboard when the dialog is displayed
                                    keyboardController?.show()
                                }
                                .onFocusChanged {
                                    // Remember the keyboard controller to show/hide the keyboard
                                    keyboardController = LocalSoftwareKeyboardController.current
                                }
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 16.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            // Buttons in the dialog
                            IconButton(onClick = {
                                // Handle the positive action (e.g., "Done" button)
                                isDialogVisible = false
                            }) {
                                Icon(imageVector = Icons.Default.Done, contentDescription = "Done")
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            IconButton(onClick = {
                                // Handle the negative action (e.g., "Close" button)
                                isDialogVisible = false
                            }) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                            }
                        }
                    }
                }
            )
        }
    }
}