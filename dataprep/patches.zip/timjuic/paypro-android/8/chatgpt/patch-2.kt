import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.material3.icons.Icons
import androidx.compose.material3.icons.filled.Close
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import com.example.featherandroidtasks.ui.theme.FeatherAndroidTasksTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeletingMerchants(
    onCreateMerchantButtonClick: () -> Unit
){

    var merchantName by remember { mutableStateOf("Eg. Konzum") }
    var isDialogVisible by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight()
            .padding()
            .background(color = Color.White),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top,
    ) {
        Text(
            text = "PayPro",
            fontSize = 50.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier
                .padding(vertical = 20.dp)
                .wrapContentSize(Alignment.TopCenter)
        )
        Button(onClick = { isDialogVisible = true }) {
            Text(text = "Show Delete Merchant Modal")
        }

        // Modal Dialog
        if (isDialogVisible) {
            Dialog(
                onDismissRequest = {
                    // Handle dismissal, if needed
                    isDialogVisible = false
                },
                content = {
                    var keyboardController by remember { mutableStateOf<SoftwareKeyboardController?>(null) }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                            .background(color = Color.LightGray)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text(
                                text = "Enter your full Merchant name to delete",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )

                            BasicTextField(
                                value = merchantName,
                                onValueChange = { newValue -> merchantName = newValue },
                                keyboardOptions = KeyboardOptions.Default.copy(
                                    keyboardType = KeyboardType.Text,
                                    imeAction = ImeAction.Done
                                ),
                                keyboardActions = KeyboardActions(
                                    onDone = {
                                        // Handle the "Done" action, if needed
                                        isDialogVisible = false
                                    }
                                ),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp)
                                    .onGloballyPositioned {
                                        // Automatically show the keyboard when the dialog is displayed
                                        keyboardController?.show()
                                    }
                                    .onFocusChanged {
                                        // Remember the keyboard controller to show/hide the keyboard
                                        keyboardController = LocalSoftwareKeyboardController.current
                                    }
                            )

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 16.dp),
                                horizontalArrangement = Arrangement.End
                            ) {
                                // Buttons in the dialog
                                IconButton(onClick = {
                                    // Handle the positive action (e.g., "Delete" button)
                                    // Add your delete logic here
                                    isDialogVisible = false
                                }) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = "Delete")
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                IconButton(onClick = {
                                    // Handle the negative action (e.g., "Cancel" button)
                                    isDialogVisible = false
                                }) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = "Cancel")
                                }
                            }
                        }
                    }
                }
            )
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FeatherAndroidTasksTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.White
                ) {
                    // Display your content
                    DeletingMerchants(onCreateMerchantButtonClick = {})
                }
            }
        }
    }
}