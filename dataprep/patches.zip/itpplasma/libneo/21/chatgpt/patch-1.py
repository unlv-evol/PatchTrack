# my_module.py

def add(a, b):
    return a + b