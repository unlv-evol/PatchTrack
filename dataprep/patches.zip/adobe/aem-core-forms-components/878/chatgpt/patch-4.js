import jsonData from './data.json';
import './styles.css';