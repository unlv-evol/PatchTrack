const baseUrl = `${this.baseNodeUrl}osmosis/concentratedliquidity/v1beta1/liquidity_net_in_direction`;

const url = new URL(baseUrl);

url.searchParams.append('pool_id', poolId);
url.searchParams.append('token_in', tokenInDenom);
url.searchParams.append('use_cur_tick', 'true');
url.searchParams.append('bound_tick', boundTickIndex);

const res = await fetch(url);
