private MutableLiveData<AuthRequestEvent> requestAuthEvent = new MutableLiveData<>();

public LiveData<AuthRequestEvent> getRequestAuthEvent() {
    return requestAuthEvent;
}

public void requestAuth() {
    requestAuthEvent.setValue(new AuthRequestEvent());
}
