const prompts = require('prompts');

async function editList() {
    let list = [];

    while (true) {
        console.log('Current List:', list.join(', '));

        const response = await prompts({
            type: 'select',
            name: 'action',
            message: 'What do you want to do?',
            choices: [
                { title: 'Add Item', value: 'add' },
                { title: 'Remove Item', value: 'remove' },
                { title: 'Exit', value: 'exit' }
            ],
        });

        if (response.action === 'add') {
            const newItem = await prompts({
                type: 'text',
                name: 'item',
                message: 'Enter item to add:',
            });
            list.push(newItem.item);
        } else if (response.action === 'remove') {
            const removeItem = await prompts({
                type: 'select',
                name: 'item',
                message: 'Select item to remove:',
                choices: list.map((item, index) => ({ title: item, value: index })),
            });
            list.splice(removeItem.item, 1);
        } else if (response.action === 'exit') {
            break;
        }
    }

    console.log('Final List:', list.join(', '));
}

editList();