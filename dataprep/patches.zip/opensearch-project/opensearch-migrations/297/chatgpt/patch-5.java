MDC.put("userId", "12345");
logger.info("User logged in");
