import axios, { AxiosResponse, AxiosError } from 'axios';

interface SuccessResponse {
  status: 'success';
  data: any; // 실제 성공 데이터 타입
}

interface FailedResponse {
  status: 'error';
  message: string; // 실패 시 메시지 타입
}

export async function fetchData(requestData: any): Promise<SuccessResponse | FailedResponse> {
  try {
    const response: AxiosResponse<SuccessResponse> = await axios.post('your-api-url', requestData);
    return response.data;
  } catch (error) {
    const axiosError = error as AxiosError<FailedResponse>;
    if (axiosError.response) {
      return axiosError.response.data;
    } else {
      // 네트워크 오류 등 예외 상황 처리
      throw error;
    }
  }
}
