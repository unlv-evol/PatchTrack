import axios, { AxiosResponse, AxiosError } from 'axios';

interface SuccessResponse {
  status: 'success';
  data: any; // 실제 성공 데이터 타입
}

interface FailedResponse {
  status: 'error';
  message: string; // 실패 시 메시지 타입
}

async function fetchData() {
  try {
    const response: AxiosResponse<SuccessResponse> = await axios.post('your-api-url', requestData);
    const successData = response.data.data;
    // 성공 데이터 사용
  } catch (error) {
    const axiosError = error as AxiosError<FailedResponse>;
    if (axiosError.response) {
      const errorMessage = axiosError.response.data.message;
      // 실패 메시지 사용
    } else {
      // 네트워크 오류 등 예외 상황 처리
    }
  }
}
