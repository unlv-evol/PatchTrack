import axios from 'axios';

// Axios 요청 보내기
axios.post('your-api-url', requestData)
  .then((response: AxiosResponse<SuccessResponse>) => {
    // 성공 응답 처리
    const successData = response.data.data;
    // 성공 데이터 사용
  })
  .catch((error: AxiosError<FailedResponse>) => {
    // 실패 응답 처리
    const errorMessage = error.response?.data.message;
    // 실패 메시지 사용
  });
