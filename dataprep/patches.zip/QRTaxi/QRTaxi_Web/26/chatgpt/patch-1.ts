interface SuccessResponse {
  status: 'success';
  data: any; // 실제 성공 데이터 타입
}

interface FailedResponse {
  status: 'error';
  message: string; // 실패 시 메시지 타입
}
