// handleVisibilityChange 함수 정의
async function handleVisibilityChangeWrapper(ws_url, id, navigate) {
    try {
        await handleVisibilityChange(ws_url, id, navigate);
    } catch (error) {
        console.error(error);
    }
}

// 이벤트 리스너 추가
document.addEventListener('visibilitychange', () => {
    handleVisibilityChangeWrapper(ws_url, id, navigate);
});
