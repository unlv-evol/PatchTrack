// handleVisibilityChange 함수 정의
async function handleVisibilityChangeWrapper(ws_url, id, navigate) {
    try {
        await handleVisibilityChange(ws_url, id, navigate);
    } catch (error) {
        console.error(error);
    }
}

// 이벤트 리스너 함수 정의
function visibilityChangeListener() {
    handleVisibilityChangeWrapper(ws_url, id, navigate);
}

// 이벤트 리스너 추가
document.addEventListener('visibilitychange', visibilityChangeListener);

// 이벤트 리스너 제거
document.removeEventListener('visibilitychange', visibilityChangeListener);
