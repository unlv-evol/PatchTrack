// 이벤트 리스너 함수 정의
function visibilityChangeListener(ws_url, id, navigate) {
    return () => {
        handleVisibilityChange(ws_url, id, navigate).catch(error =>
            console.error(error)
        );
    };
}

// 이벤트 리스너 추가
const listener = visibilityChangeListener(ws_url, id, navigate);
document.addEventListener('visibilitychange', listener);

// 이벤트 리스너 제거
document.removeEventListener('visibilitychange', listener);
