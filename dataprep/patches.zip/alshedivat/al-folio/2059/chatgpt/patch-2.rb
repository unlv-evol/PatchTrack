require 'nokogiri'

# ...

def fetch_from_urls(site, src)
  src['urls'].each do |url|
    p "...fetching #{url}"
    content = fetch_content_from_url(url)
    create_document(site, src['name'], url, content)
  end
end

def fetch_content_from_url(url)
  html = HTTParty.get(url).body
  parsed_html = Nokogiri::HTML(html)

  title = parsed_html.at('head title')&.text || ''
  description = parsed_html.at('head meta[name="description"]')&.attr('content') || ''
  body_content = parsed_html.at('body')&.inner_html || ''

  {
    title: title,
    content: body_content,
    summary: description,
    published: Time.now # Placeholder for the published date
  }
end

# ...