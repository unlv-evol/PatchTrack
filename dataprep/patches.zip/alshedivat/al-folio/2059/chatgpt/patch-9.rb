def fetch_from_urls(site, src)
  src['posts'].each do |post|
    puts "...fetching #{post['url']}"
    content = fetch_content_from_url(post['url'])
    published_date = post['published_date']

    # Convert to Time object depending on the type of 'published_date'
    content[:published] = case published_date
                          when String
                            Time.parse(published_date).utc
                          when Date
                            published_date.to_time.utc
                          else
                            raise "Invalid date format for #{published_date}"
                          end

    create_document(site, src['name'], post['url'], content)
  end
end