def fetch_from_urls(site, src)
  src['posts'].each do |post|
    puts "...fetching #{post['url']}"  # Changed 'p' to 'puts' here
    content = fetch_content_from_url(post['url'])
    content[:published] = post['published_date'] # Use the provided published date
    create_document(site, src['name'], post['url'], content)
  end
end

# Rest of your code remains the same...