require 'feedjira'
require 'httparty'
require 'jekyll'
require 'nokogiri' # Add if needed for HTML parsing

module ExternalPosts
  class ExternalPostsGenerator < Jekyll::Generator
    safe true
    priority :high

    def generate(site)
      if site.config['external_sources'] != nil
        site.config['external_sources'].each do |src|
          if src['rss_url']
            fetch_from_rss(site, src)
          elsif src['urls']
            fetch_from_urls(site, src)
          end
        end
      end
    end

    def fetch_from_rss(site, src)
      p "Fetching external posts from #{src['name']}:"
      xml = HTTParty.get(src['rss_url']).body
      feed = Feedjira.parse(xml)
      process_entries(site, src, feed.entries)
    end

    def fetch_from_urls(site, src)
      src['urls'].each do |url|
        p "...fetching #{url}"
        content = fetch_content_from_url(url)
        # Here you need to extract title, summary, content, etc. from 'content'
        # The following is a placeholder for the real extraction logic.
        # e.g., title = content[:title], summary = content[:summary]
        create_document(site, src['name'], url, content)
      end
    end

    def fetch_content_from_url(url)
      # Fetch and parse the HTML content from the URL
      # Return a hash or similar structure containing the post's details
      # This is a placeholder method
      html = HTTParty.get(url).body
      # Use Nokogiri or similar library to parse HTML and extract post details
      # For example: Nokogiri::HTML(html).at('h1').text for the title
      # return { title: ..., content: ..., summary: ..., published: ... }
    end

    def process_entries(site, src, entries)
      entries.each do |e|
        p "...fetching #{e.url}"
        create_document(site, src['name'], e.url, {
          title: e.title,
          content: e.content,
          summary: e.summary,
          published: e.published
        })
      end
    end

    def create_document(site, source_name, url, content)
      slug = content[:title].downcase.strip.gsub(' ', '-').gsub(/[^\w-]/, '')
      path = site.in_source_dir("_posts/#{slug}.md")
      doc = Jekyll::Document.new(
        path, { :site => site, :collection => site.collections['posts'] }
      )
      doc.data['external_source'] = source_name
      doc.data['feed_content'] = content[:content]
      doc.data['title'] = content[:title]
      doc.data['description'] = content[:summary]
      doc.data['date'] = content[:published]
      doc.data['redirect'] = url
      site.collections['posts'].docs << doc
    end
  end
end