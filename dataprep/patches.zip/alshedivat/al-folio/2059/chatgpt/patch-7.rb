require 'date'

    # ...

    def fetch_from_urls(site, src)
      src['posts'].each do |post|
        puts "...fetching #{post['url']}"
        content = fetch_content_from_url(post['url'])
        content[:published] = Date.parse(post['published_date'])
        create_document(site, src['name'], post['url'], content)
      end
    end

    # ...