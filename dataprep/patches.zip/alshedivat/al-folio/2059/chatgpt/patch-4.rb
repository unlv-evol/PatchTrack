require 'nokogiri'

# ...

def fetch_from_urls(site, src)
  src['posts'].each do |post|
    p "...fetching #{post['url']}"
    content = fetch_content_from_url(post['url'])
    content[:published] = post['published_date'] # Use the provided published date
    create_document(site, src['name'], post['url'], content)
  end
end

def fetch_content_from_url(url)
  html = HTTParty.get(url).body
  parsed_html = Nokogiri::HTML(html)

  title = parsed_html.at('head title')&.text || ''
  description = parsed_html.at('head meta[name="description"]')&.attr('content') || ''
  body_content = parsed_html.at('body')&.inner_html || ''

  {
    title: title,
    content: body_content,
    summary: description
    # Note: The published date is now added in the fetch_from_urls method
  }
end

# ...