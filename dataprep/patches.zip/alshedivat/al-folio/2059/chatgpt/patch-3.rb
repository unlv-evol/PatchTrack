def fetch_content_from_url(url)
  response = HTTParty.get(url)
  html = response.body
  parsed_html = Nokogiri::HTML(html)

  title = parsed_html.at('head title')&.text || ''
  description = parsed_html.at('head meta[name="description"]')&.attr('content') || ''
  body_content = parsed_html.at('body')&.inner_html || ''
  published = parse_published_date(parsed_html, response.headers)

  {
    title: title,
    content: body_content,
    summary: description,
    published: published
  }
end

def parse_published_date(parsed_html, headers)
  # Try to extract from metadata
  published_meta = parsed_html.at('head meta[property="article:published_time"], head meta[name="published"], head meta[property="og:published_time"]')&.attr('content')
  return published_meta if published_meta

  # Try to extract from article tag
  published_article = parsed_html.at('article time')&.attr('datetime')
  return published_article if published_article

  # Fallback to Last-Modified header
  headers['Last-Modified'] || Time.now
end