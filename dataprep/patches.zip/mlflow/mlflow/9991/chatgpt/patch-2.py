import mlflow
   
   def f():
       global mlflow  # Indicates we're using the global `mlflow`
       print(mlflow)
       import mlflow.gateway
   
   f()