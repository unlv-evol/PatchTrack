# Initialize the global counter
$counter = 0

# A method to increment the counter
def increment_counter
  $counter += 1
end

# Using the counter
increment_counter
puts $counter # Outputs: 1

increment_counter
puts $counter # Outputs: 2

# ... and so on