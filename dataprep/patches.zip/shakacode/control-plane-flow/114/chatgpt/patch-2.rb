class Counter
  # Initialize the class variable
  @@counter = 0

  # Class method to increment the counter
  def self.increment
    @@counter += 1
  end

  # Class method to get the current value of the counter
  def self.value
    @@counter
  end
end

# Using the counter
Counter.increment
puts Counter.value # Outputs: 1

Counter.increment
puts Counter.value # Outputs: 2

# ... and so on