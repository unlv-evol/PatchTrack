class Counter
  # Class method to initialize or increment the counter
  def self.increment
    # Initialize the counter if it doesn't exist
    @counter ||= 0
    @counter += 1
  end

  # Class method to get the current value of the counter
  def self.value
    @counter || 0
  end
end

# Using the counter
Counter.increment
puts Counter.value # Outputs: 1

Counter.increment
puts Counter.value # Outputs: 2

# ... and so on