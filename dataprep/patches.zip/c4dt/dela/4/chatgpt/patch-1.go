package main

import "fmt"

// Define some lambda functions
var add = func(a, b int) int {
    return a + b
}

var subtract = func(a, b int) int {
    return a - b
}

var multiply = func(a, b int) int {
    return a * b
}

var divide = func(a, b int) int {
    if b == 0 {
        return -1 // Return -1 to indicate division by zero
    }
    return a / b
}

func main() {
    // Create a dispatch table using a map
    operationTable := map[string]func(int, int) int{
        "add":      add,
        "subtract": subtract,
        "multiply": multiply,
        "divide":   divide,
    }

    // Perform operations using the dispatch table
    a, b := 10, 5

    operation := "add"
    result := operationTable[operation](a, b)
    fmt.Printf("%d %s %d = %d\n", a, operation, b, result)

    operation = "subtract"
    result = operationTable[operation](a, b)
    fmt.Printf("%d %s %d = %d\n", a, operation, b, result)

    operation = "multiply"
    result = operationTable[operation](a, b)
    fmt.Printf("%d %s %d = %d\n", a, operation, b, result)

    operation = "divide"
    result = operationTable[operation](a, b)
    if result == -1 {
        fmt.Printf("Cannot divide by zero\n")
    } else {
        fmt.Printf("%d %s %d = %d\n", a, operation, b, result)
    }
}