bundle update [gem_name]
