type PrefixMap = {
  nprofile: ProfilePointer
  nrelay: string
  nevent: EventPointer
  naddr: AddressPointer
  nsec: string
  npub: string
  note: string
}

type DecodeValue<Prefix extends keyof PrefixMap = keyof PrefixMap> = {
  type: Prefix
  data: PrefixMap[Prefix]
}

export type DecodeResult = {
  [P in keyof PrefixMap]: DecodeValue<P>
}[keyof PrefixMap]
