import os
from collections import OrderedDict

class LRUFileCache:
    def __init__(self, file_path: str, max_size: int):
        self.file_path = file_path
        self.max_size = max_size
        self.current_size = 0
        self.files = OrderedDict()  # {filename: size}

        # initialize the file cache
        for file in os.listdir(file_path):
            file_full_path = os.path.join(file_path, file)
            file_size = os.path.getsize(file_full_path)
            self.current_size += file_size
            self.files[file] = file_size

    def _evict_files(self):
        while self.current_size > self.max_size:
            _, evicted_size = self.files.popitem(last=False)  # pop the least recently accessed item
            self.current_size -= evicted_size

    def read_file(self, filename: str) -> str:
        file_full_path = os.path.join(self.file_path, filename)
        if not os.path.exists(file_full_path):
            raise ValueError(f"{filename} doesn't exist!")

        with open(file_full_path, 'r') as f:
            content = f.read()

        # Move accessed file to the end to maintain LRU order
        file_size = self.files.pop(filename)
        self.files[filename] = file_size

        return content

    def create_file(self, filename: str, content: str):
        file_full_path = os.path.join(self.file_path, filename)
        with open(file_full_path, 'w') as f:
            f.write(content)

        file_size = os.path.getsize(file_full_path)
        self.current_size += file_size
        self.files[filename] = file_size

        self._evict_files()

    def delete_file(self, filename: str):
        if filename in self.files:
            file_full_path = os.path.join(self.file_path, filename)
            os.remove(file_full_path)
            size = self.files.pop(filename)
            self.current_size -= size

# Usage
file_cache = LRUFileCache("path/to/files", 5000)  # max_size in bytes, for example: 5 KB
file_cache.create_file("sample.txt", "Hello World")
content = file_cache.read_file("sample.txt")