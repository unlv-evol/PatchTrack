Schema::create('locations', function (Blueprint $table) {
    $table->id();
    // 緯度
    $table->decimal('latitude', 10, 8);
    // 経度
    $table->decimal('longitude', 11, 8);
    $table->timestamps();
});