// In your controller method
public function redirectToNewPage()
{
    // Flash the message to the session
    session()->flash('message', 'Your message goes here');

    // Redirect to the new page
    return redirect()->route('new-page');
}
