package main

import (
	"fmt"
	"time"

	"github.com/dgrijalva/jwt-go"
)

func main() {
	myToken := "your-jwt-token-here"

	// Parse the token
	token, err := jwt.Parse(myToken, func(token *jwt.Token) (interface{}, error) {
		// Don't forget to validate the alg is what you expect:
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("Unexpected signing method: %v", token.Header["alg"])
		}
		return []byte("your-secret"), nil
	})

	if err != nil {
		fmt.Println("Error while parsing the token:", err)
		return
	}

	if claims, ok := token.Claims.(jwt.MapClaims); ok && token.Valid {
		// Convert the Unix timestamp from the token to time.Time
		if exp, ok := claims["exp"].(float64); ok {
			// Convert the float64 to an int64
			expTime := time.Unix(int64(exp), 0)
			currTime := time.Now()

			if currTime.After(expTime) {
				fmt.Println("Token is expired")
			} else {
				fmt.Println("Token is still valid")
			}
		} else {
			fmt.Println("Unable to find or convert expiration time")
		}
	} else {
		fmt.Println("Token is not valid")
	}
}