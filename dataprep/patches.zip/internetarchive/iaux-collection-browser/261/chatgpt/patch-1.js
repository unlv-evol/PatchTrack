const firstLetter = this.selectedCreatorFilter.toUpperCase();

displayedCreator =
  this.model.creators.find(creator => 
    creator.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().startsWith(firstLetter)
  ) ?? displayedCreator;
