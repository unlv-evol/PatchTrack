const firstLetter = this.selectedCreatorFilter.toUpperCase();

displayedCreator =
  this.model.creators.find(creator => 
    creator.normalize("NFD").toUpperCase().startsWith(firstLetter)
  ) ?? displayedCreator;
