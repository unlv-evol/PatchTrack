import requests

# Jira API endpoint to retrieve project information
api_url = 'https://your-jira-url.com/rest/api/2/project/{project_key}'

# Replace 'username' and 'password' with your Jira credentials
auth = ('username', 'password')

# Specify the project key associated with the board
project_key = 'YOUR_PROJECT_KEY'

# Send a GET request to the API endpoint
response = requests.get(api_url.format(project_key=project_key), auth=auth)

if response.status_code == 200:
    project_info = response.json()
    permissions = project_info.get('permissions', {})
    create_issue_permission = permissions.get('CREATE_ISSUES', False)

    if create_issue_permission:
        print(f"You have permissions to create an issue on project {project_key}.")
    else:
        print(f"You do not have permissions to create an issue on project {project_key}.")
else:
    print(f"Failed to retrieve project information for {project_key}.")
