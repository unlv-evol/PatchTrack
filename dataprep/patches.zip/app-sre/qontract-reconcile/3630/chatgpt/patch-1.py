from jira import JIRA

jira = JIRA(server='https://your-jira-url.com', basic_auth=('username', 'password'))
