program ::= statement*

statement ::= resource_declaration
            | output_declaration
            | parameter_declaration
            | variable_declaration
            | module_declaration

resource_declaration ::= 'resource' resource_identifier '=' 'type' '{' property_declaration* '}'

output_declaration ::= 'output' output_identifier '=' output_value

parameter_declaration ::= 'param' parameter_identifier parameter_type '=' default_value

variable_declaration ::= 'var' variable_identifier '=' variable_value

module_declaration ::= 'module' module_identifier '=' 'moduleName' '{' module_property* '}'

property_declaration ::= property_identifier '=' property_value

output_value ::= expression

parameter_type ::= 'string' | 'int' | 'bool' | 'object' | 'array'

default_value ::= literal_value | expression

variable_value ::= literal_value | expression

expression ::= literal_value
             | function_call
             | property_access
             | array_access
             | binary_operation
             | unary_operation

literal_value ::= string_literal | int_literal | bool_literal | object_literal | array_literal

string_literal ::= '"' string_content '"'
                | "'" string_content "'"

int_literal ::= [0-9]+

bool_literal ::= 'true' | 'false'

object_literal ::= '{' property_declaration* '}'

array_literal ::= '[' (literal_value (',' literal_value)*)? ']'

function_call ::= function_name '(' function_arguments ')'

property_access ::= expression '.' property_identifier

array_access ::= expression '[' expression ']'

binary_operation ::= expression binary_operator expression

unary_operation ::= unary_operator expression

binary_operator ::= '+' | '-' | '*' | '/' | '%' | '==' | '!=' | '>' | '>=' | '<' | '<=' | '&&' | '||'

unary_operator ::= '-' | '!' | '++' | '--'

comment ::= '//' comment_text
           | '/*' comment_text '*/'

comment_text ::= [^'\n']*

resource_identifier ::= identifier

output_identifier ::= identifier

parameter_identifier ::= identifier

variable_identifier ::= identifier

module_identifier ::= identifier

identifier ::= [a-zA-Z_][a-zA-Z0-9_]*