WITH deleted_rows AS (
    SELECT peer, game, lobbies 
    FROM timeouts
    WHERE last_seen < $1
    LIMIT 1
)
DELETE FROM timeouts
USING deleted_rows
WHERE timeouts.peer = deleted_rows.peer
AND timeouts.game = deleted_rows.game
AND timeouts.lobbies = deleted_rows.lobbies
RETURNING deleted_rows.peer, deleted_rows.game, deleted_rows.lobbies;
