const fs = require('fs').promises; // Using fs.promises for asynchronous file operations
const util = require('util');

// Async function to read a JSON file
async function readJsonFile(filePath) {
  try {
    // Read the file using fs.promises.readFile and await for the result
    const data = await fs.readFile(filePath, 'utf8');
    
    // Parse the JSON data
    const jsonData = JSON.parse(data);
    
    // Return the parsed JSON object
    return jsonData;
  } catch (error) {
    // Handle errors, e.g., file not found
    throw new Error('Error reading JSON file: ' + error.message);
  }
}

// Example usage
async function main() {
  const filePath = 'path/to/your/file.json'; // Specify the path to your JSON file
  try {
    // Call the async function and wait for the result
    const jsonContent = await readJsonFile(filePath);
    
    // Use the JSON content as needed
    console.log(jsonContent);
  } catch (error) {
    console.error(error.message);
  }
}

// Call the main function to start the process
main();