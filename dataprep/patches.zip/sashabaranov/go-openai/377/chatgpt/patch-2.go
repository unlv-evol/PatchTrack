package main

import (
	"encoding/json"
)

type parametersObj struct {
	// define your parametersObj struct fields here
}

type FunctionDefine struct {
	Name           string          `json:"name"`
	Description    string          `json:"description,omitempty"`
	ParametersRaw  json.RawMessage `json:"-"`
	Parameters     parametersObj   `json:"-"`
}

func (fd FunctionDefine) MarshalJSON() ([]byte, error) {
	type Alias FunctionDefine
	var parameters json.RawMessage
	var err error

	if fd.ParametersRaw != nil {
		parameters = fd.ParametersRaw
	} else {
		parameters, err = json.Marshal(fd.Parameters)
		if err != nil {
			return nil, err
		}
	}

	return json.Marshal(&struct {
		*Alias
		Parameters json.RawMessage `json:"parameters"`
	}{
		Alias:      (*Alias)(&fd),
		Parameters: parameters,
	})
}

func main() {
	// Test your custom JSON marshaler here
}
