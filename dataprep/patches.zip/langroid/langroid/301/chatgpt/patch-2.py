from github import Github

   # Replace with your GitHub access token
   access_token = "YOUR_ACCESS_TOKEN"

   # Replace with the repository you're interested in, e.g., "owner/repo"
   repo_name = "owner/repo"

   # Create a Github instance:
   g = Github(access_token)

   # Get the repository
   repo = g.get_repo(repo_name)

   # List all tags
   tags = repo.get_tags()

   # Assuming the most recent tag is the latest version
   latest_version = tags[0].name if tags.totalCount > 0 else "No version tags found"

   print(f"Latest version: {latest_version}")