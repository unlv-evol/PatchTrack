git checkout second-pr-branch
    git rebase main