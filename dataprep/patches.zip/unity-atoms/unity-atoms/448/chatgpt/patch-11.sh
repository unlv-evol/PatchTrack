git status
    git diff --cached