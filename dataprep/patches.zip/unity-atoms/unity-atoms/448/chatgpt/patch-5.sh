git checkout main
    git pull origin main