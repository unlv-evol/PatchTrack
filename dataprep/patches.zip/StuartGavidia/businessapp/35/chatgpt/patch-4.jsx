// Spinner.js
import React from 'react';

const Spinner = () => {
  return (
    <div className="spinner">
      {/* Your spinner content (e.g., loading animation) */}
      Loading...
    </div>
  );
};

export default Spinner;