// YourComponent.js
import React, { useEffect } from 'react';
import { useLoading } from './LoadingContext';

const YourComponent = () => {
  const { startLoading, stopLoading } = useLoading();

  useEffect(() => {
    // Simulate an asynchronous operation (e.g., API call)
    startLoading();
    setTimeout(() => {
      // Your actual logic here
      stopLoading();
    }, 2000);
  }, [startLoading, stopLoading]);

  return (
    <div>
      {/* Your component content */}
    </div>
  );
};

export default YourComponent;