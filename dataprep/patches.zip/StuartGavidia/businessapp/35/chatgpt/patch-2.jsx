// App.js
import React from 'react';
import { LoadingProvider } from './LoadingContext';
import Routes from './Routes';

const App = () => {
  return (
    <LoadingProvider>
      <Routes />
    </LoadingProvider>
  );
};

export default App;