async function handleDataRequest(url: string) {
  try {
    const data = await fetchData(url);
    console.log('Data fetched successfully:', data);
  } catch (error) {
    if (error instanceof SessionExpiredError) {
      console.error('Session expired:', error.message);
      // Handle session expiry, for example, redirect to login
    } else if (error instanceof GenericError) {
      console.error('A generic error occurred:', error.message);
      // Handle generic errors
    } else {
      console.error('An unexpected error occurred:', error);
      // Handle unexpected errors
    }
  }
}

// Usage example:
handleDataRequest('https://api.example.com/data');