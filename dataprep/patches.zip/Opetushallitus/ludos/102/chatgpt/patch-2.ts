async function fetchData(url: string): Promise<any> {
  try {
    const response = await fetch(url);
    
    // Check for session expiry
    if (response.status === 401) { // 401 is typically used for authentication errors
      throw new SessionExpiredError('Session has expired. Please log in again.');
    }
    
    // Handle other potential bad statuses
    if (!response.ok) {
      throw new GenericError('An error occurred while fetching data.');
    }
    
    const data = await response.json();
    return data;
  } catch (error) {
    // Re-throw the error to be handled by the caller
    throw error;
  }
}