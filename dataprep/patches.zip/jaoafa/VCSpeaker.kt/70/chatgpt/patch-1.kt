import com.sksamuel.scrimage.ImmutableImage
import com.sksamuel.scrimage.color.RGBColor

fun main() {
    // 画像の幅と高さを設定
    val width = 400
    val height = 200

    // 画像を生成し、背景を白色で塗りつぶす
    val image = ImmutableImage.filled(width, height, RGBColor.WHITE)

    // 描画する文字列とフォントサイズを設定
    val text = "Hello, World!"
    val fontSize = 24f

    // 文字列を描画する位置を設定
    val x = 50
    val y = 100

    // 文字列の色と縁取りの色を設定
    val textColor = RGBColor.WHITE
    val outlineColor = RGBColor.BLACK

    // 文字列を画像上に描画
    image.awt().graphics.apply {
        font = font.deriveFont(fontSize)
        color = textColor.toAWTColor()
        drawString(text, x, y)
    }

    // 文字列に縁取りを追加
    val outlinedImage = image.awt().graphics.apply {
        color = outlineColor.toAWTColor()
        font = font.deriveFont(fontSize)
        drawString(text, x - 1, y - 1)
        drawString(text, x + 1, y - 1)
        drawString(text, x - 1, y + 1)
        drawString(text, x + 1, y + 1)
    }

    // 画像を保存
    outlinedImage.dispose()
    image.output("outlined_text.png")
}