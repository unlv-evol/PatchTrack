if [[ -z "$MD5_PATH" ]]; then
  echo "md5sum command not found"
  exit 1
fi
