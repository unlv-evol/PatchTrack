MD5_PATH="$(exec <&- 2>&-; which md5sum || command -v md5sum || type md5sum)"
