const myArray: number[] = [];

// Check if the array is null or empty
if (!myArray) {
    console.log("Array is null or empty");
} else {
    console.log("Array is not null or empty");
}