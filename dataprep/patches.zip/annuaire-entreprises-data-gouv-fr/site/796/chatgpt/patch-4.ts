const myVariable: any = /* some value */;

   // Check if the variable is null or empty
   if (!myVariable) {
       console.log("Variable is null or empty");
   }