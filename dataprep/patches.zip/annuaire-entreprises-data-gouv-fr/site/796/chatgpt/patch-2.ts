const myArray: number[] = [1, 2, 3];

   // Check if the array is null or empty
   if (!myArray || myArray.length === 0) {
       console.log("Array is null or empty");
   }