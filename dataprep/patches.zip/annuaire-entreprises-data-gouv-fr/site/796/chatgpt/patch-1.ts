const myString: string = "Hello, World!";

   // Check if the string is null or empty
   if (!myString) {
       console.log("String is null or empty");
   }