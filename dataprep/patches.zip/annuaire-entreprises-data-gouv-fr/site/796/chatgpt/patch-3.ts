const myObject: { key: string } = { key: "value" };

   // Check if the object is null or empty
   if (!myObject || Object.keys(myObject).length === 0) {
       console.log("Object is null or empty");
   }