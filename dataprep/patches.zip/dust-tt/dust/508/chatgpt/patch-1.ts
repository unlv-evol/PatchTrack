export function getProviderLogoPathForDataSource(
  ds: DataSourceType
): string | null {
  const provider = ds.connectorProvider;

  if (!provider) {
    return null;
  }

  switch (provider) {
    case "notion":
      return `/static/notion_32x32.png`;

    case "slack":
      return `/static/slack_32x32.png`;

    case "github":
      return `/static/github_black_32x32.png`;

    default:
      return assertNever(provider);
  }
}

function assertNever(value: never): never {
    throw new Error(`Unexpected value '${value}'`);
}
