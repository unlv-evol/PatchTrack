type AppProps = { message: string };

     const App: React.VFC<AppProps> = ({ message }) => <div>{message}</div>;