type AppProps = { message: string };

     const App: React.FC<AppProps> = ({ message }) => <div>{message}</div>;