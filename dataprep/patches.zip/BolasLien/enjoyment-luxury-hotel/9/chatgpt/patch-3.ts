type AppProps = { message: string };

const App = ({ message }: AppProps) => <div>{message}</div>;