// ... (previous code)

rescueStdout := os.Stdout
r, w, _ := os.Pipe()
os.Stdout = w

// Use defer to ensure that w is closed regardless of what happens next
defer func() {
    w.Close()
    os.Stdout = rescueStdout
}()

if err := root.Execute(); err != nil {
    t.Fatal(err)
}

// Check for errors when reading from the pipe
out, err := io.ReadAll(r)
if err != nil {
    t.Fatal(err)
}

// ... (rest of the code)