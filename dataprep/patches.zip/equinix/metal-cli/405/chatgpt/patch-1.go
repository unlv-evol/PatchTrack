// ... (previous code)

rescueStdout := os.Stdout
r, w, _ := os.Pipe()
os.Stdout = w
if err := root.Execute(); err != nil {
    t.Error(err)
    return
}
w.Close()
os.Stdout = rescueStdout

// Check for errors when reading from the pipe
out, err := io.ReadAll(r)
if err != nil {
    t.Error(err)
}

// ... (rest of the code)