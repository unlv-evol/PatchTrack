// ... (previous code)

rescueStdout := os.Stdout
r, w, _ := os.Pipe()
os.Stdout = w
if err := root.Execute(); err != nil {
    os.Stdout = rescueStdout
    w.Close()
    t.Fatal(err)
}

w.Close()
os.Stdout = rescueStdout

// Check for errors when reading from the pipe
out, err := io.ReadAll(r)
if err != nil {
    t.Fatal(err)
}

// ... (rest of the code)