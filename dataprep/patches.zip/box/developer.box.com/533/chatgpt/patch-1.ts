class MyClass {
    /**
     * @deprecated This method is deprecated. Use myNewMethod instead.
     */
    oldMethod() {
        // Deprecated method implementation
    }

    myNewMethod() {
        // New method implementation
    }
}

const obj = new MyClass();

// Using the deprecated method
obj.oldMethod(); // This will generate a warning in most IDEs and linting tools