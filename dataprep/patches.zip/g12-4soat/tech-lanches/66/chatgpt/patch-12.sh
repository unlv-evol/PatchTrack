kubectl apply -f techlanches-api-service.yaml
kubectl apply -f techlanches-worker-service.yaml