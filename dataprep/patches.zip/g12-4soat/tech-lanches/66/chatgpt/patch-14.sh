kubectl apply -f techlanches-api-hpa.yaml
kubectl apply -f techlanches-worker-hpa.yaml