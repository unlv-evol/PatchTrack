kubectl apply -f techlanches-api-deployment.yaml
kubectl apply -f techlanches-worker-deployment.yaml