const orderedDict = new Map<string, any>();

orderedDict.set("key1", "value1");
orderedDict.set("key2", "value2");
orderedDict.set("key3", "value3");

for (const value of orderedDict.values()) {
  console.log(value);
}
