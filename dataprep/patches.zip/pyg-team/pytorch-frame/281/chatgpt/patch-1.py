def example_function(arg=None):
    if arg is None:
        arg = {}
    # proceed with the function using the arg dictionary