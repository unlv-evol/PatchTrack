interface Person {
  name: string;
  age: number;
  email?: string;
}

const person: Person = {
  name: "John Doe",
  age: 25,
};

console.log(person.name); // Output: John Doe
console.log(person.age); // Output: 25
