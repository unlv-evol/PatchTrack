import { defineConfig } from 'vite';

export default defineConfig({
  define: {
    __APP_TITLE__: JSON.stringify(process.env.VITE_APP_TITLE),
  },
});