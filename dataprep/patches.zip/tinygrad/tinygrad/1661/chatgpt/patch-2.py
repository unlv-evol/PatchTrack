if isinstance(s, int) and tensor_found: [tensor_found[i] for i in range(len(tensor_found)) if tensor_found[i][0] > i][0][0] -= 1
