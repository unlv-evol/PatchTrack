# Example without optimization
for item in some_list:
    result = item.some_method()
    # Use result in some computation

# Example with optimization
some_method = SomeClass.some_method  # Assign method to variable outside the loop
for item in some_list:
    result = some_method(item)
    # Use result in some computation