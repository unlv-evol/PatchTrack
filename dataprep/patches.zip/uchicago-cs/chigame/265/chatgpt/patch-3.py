# urls.py
from django.urls import path
from .views import AddTokenMonthlyView

urlpatterns = [
    path('add_token_monthly/', AddTokenMonthlyView.as_view(), name='add_token_monthly'),
    # Add other URLs as needed
]