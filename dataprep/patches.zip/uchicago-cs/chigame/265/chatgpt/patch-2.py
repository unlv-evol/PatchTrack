# views.py
from django.shortcuts import get_object_or_404
from django.http import HttpResponse
from django.views import View
from datetime import datetime, timedelta
from .models import UserProfile

class AddTokenMonthlyView(View):
    def get(self, request, *args, **kwargs):
        # Retrieve all user profiles
        user_profiles = UserProfile.objects.all()

        # Iterate through user profiles and add a token to each if a month has passed
        for profile in user_profiles:
            if self._is_month_passed(profile.last_token_addition):
                profile.token_count += 1
                profile.last_token_addition = datetime.now().date()
                profile.save()

        return HttpResponse("Tokens added successfully!")

    def _is_month_passed(self, last_date):
        # Check if a month has passed since the last token addition
        current_date = datetime.now().date()
        return (current_date.year, current_date.month) > (last_date.year, last_date.month)