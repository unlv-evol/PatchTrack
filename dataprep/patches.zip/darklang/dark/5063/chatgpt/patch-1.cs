char myChar = 'A';
int asciiCode = (int)myChar;
Console.WriteLine(asciiCode);  // Outputs: 65
