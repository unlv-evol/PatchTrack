let filter f lst =
    List.foldBack (fun x acc -> if f x then x :: acc else acc) lst []
