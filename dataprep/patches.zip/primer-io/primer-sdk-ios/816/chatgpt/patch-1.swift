struct MetadataParser {

    func parse(_ metadata: String?) -> [String: Any] {
        guard let metadata = metadata else { return [:] }

        if let jsonData = metadata.data(using: .utf8),
           let jsonObject = try? JSONSerialization.jsonObject(with: jsonData) as? [String: Any] {
            return jsonObject
        }

        return metadata
            .split(separator: "\n")
            .lazy
            .map { $0.split(separator: "=").map { $0.trimmingCharacters(in: .whitespaces) } }
            .filter { $0.count == 2 }
            .map { keyValue in
                (String(keyValue[0]), parseValue(String(keyValue[1])))
            }
            .reduce(into: [String: Any]()) { $0[$1.0] = $1.1 }
    }

    private func parseValue(_ value: String) -> Any {
        let lowercasedValue = value.lowercased()

        // Direct boolean parsing
        switch lowercasedValue {
        case "true": return true
        case "false": return false
        default: break
        }

        // Attempt to parse as Int first, then as Double
        if let intValue = Int(value) {
            return intValue
        } else if let doubleValue = Double(value) {
            return doubleValue
        }

        // Handle quoted strings
        if value.hasPrefix("\"") && value.hasSuffix("\"") {
            return String(value.dropFirst().dropLast())
        }

        return value
    }
}