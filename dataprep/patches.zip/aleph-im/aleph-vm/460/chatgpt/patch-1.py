import pytest
import datetime

@pytest.fixture
def patch_datetime_now(monkeypatch):
    """
    Fixture for patching the datetime.now() and datetime.utcnow() methods
    to return a fixed datetime object.

    This fixture creates a subclass of `datetime.datetime` called `mydatetime`,
    which overrides the `now()` and `utcnow()` class methods to return a fixed
    datetime object specified by `FAKE_TIME`.

    Parameters:
        monkeypatch (pytest.MonkeyPatch): The pytest monkeypatch fixture object.

    Returns:
        type: The subclass of `datetime.datetime` with patched `now()` and `utcnow()`
        methods.

    Example:
        This fixture can be used in pytest tests to mock the current date and time: