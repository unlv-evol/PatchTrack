const [filterControls, setFilterControls] = useState<{category: number, format: number}>({category: -1, format: -1});
