const NO_SELECTION = -1;

// ...

const [filterControls, setFilterControls] = useState<{ category: number, format: number }>({ category: NO_SELECTION, format: NO_SELECTION });

// ...

return events?.filter(
  (event) =>
    (filterControls.category === NO_SELECTION ||
      event.Category_f5a9cf4c_x002d_8228_x00 ===
        options.categories[filterControls.category]) &&
    (filterControls.format === NO_SELECTION ||
      event.CalendarType === options.formats[filterControls.format])
);
