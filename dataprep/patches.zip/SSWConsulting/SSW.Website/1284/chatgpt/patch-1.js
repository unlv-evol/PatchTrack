const [filterControls, setFilterControls] = useState<number[]>([-1, -1]);
