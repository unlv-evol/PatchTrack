const dayjs = require('dayjs');
require('dayjs/locale/en'); // Import the locale you want to use (e.g., 'en' for English)

const formattedDate = dayjs(event.date).format("Do (ddd) MMMM YYYY");
console.log(formattedDate);
