void free_matrix(double **matrix, int rows) {
    if (matrix == NULL) return; // Verifica se a matriz é nula

    for (int i = 0; i < rows; i++) {
        free(matrix[i]); // Libera cada linha da matriz
    }
    
    free(matrix); // Libera o ponteiro de linhas
}

// Uso:
int main() {
    int rows = 10;
    int cols = 5;

    // Alocação da matriz
    double **matrix = (double **)malloc(rows * sizeof(double *));
    for (int i = 0; i < rows; i++) {
        matrix[i] = (double *)malloc(cols * sizeof(double));
    }

    // Uso da matriz

    // Desalocação da matriz
    free_matrix(matrix, rows);

    return 0;
}