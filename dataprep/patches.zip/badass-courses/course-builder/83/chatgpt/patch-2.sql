CREATE TABLE permissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    userId VARCHAR(255),
    contentId VARCHAR(255),
    permissionType ENUM('read', 'write', 'manage'),
    FOREIGN KEY (userId) REFERENCES user(id)
);