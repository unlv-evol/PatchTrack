import { z } from 'zod';

// Define a Zod schema for a "Tip" content type
const TipSchema = z.object({
  title: z.string().min(1, "Title is required"),
  state: z.enum(['draft', 'published']),
  visibility: z.enum(['public', 'private', 'unlisted']),
  resources: z.array(z.object({
    type: z.string(),
    id: z.string(),
    title: z.string().optional(),
    url: z.string().url().optional()
  })),
  body: z.string(),
});

// Example of how you might serialize this schema to store it in your database
const serializedSchemaDefinition = JSON.stringify(TipSchema.toJSON());

console.log(serializedSchemaDefinition);