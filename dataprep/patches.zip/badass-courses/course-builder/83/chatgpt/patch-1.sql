CREATE TABLE contributions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    userId VARCHAR(255),
    contentId VARCHAR(255),
    contentType VARCHAR(50),
    role ENUM('author', 'editor', 'contributor'),
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userId) REFERENCES user(id)
);