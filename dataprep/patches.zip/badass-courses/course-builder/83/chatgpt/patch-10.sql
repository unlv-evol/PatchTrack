-- Users Table
CREATE TABLE users (
    id VARCHAR(255) PRIMARY KEY,
    name VARCHAR(255),
    role ENUM('user', 'admin') DEFAULT 'user',
    email VARCHAR(255) NOT NULL,
    emailVerified TIMESTAMP(3),
    image VARCHAR(255),
    createdAt TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP(3),
    INDEX email_idx (email),
    INDEX role_idx (role)
);

-- Content Types Table
CREATE TABLE content_types (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50),
    schemaDefinition JSON NOT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Content Metadata Table
CREATE TABLE content_metadata (
    contentId VARCHAR(255) PRIMARY KEY,
    typeId INT,
    title VARCHAR(255),
    state ENUM('draft', 'published'),
    visibility ENUM('public', 'private', 'unlisted'),
    resources JSON, -- Storing references to other content or resources
    body TEXT,
    createdBy VARCHAR(255),
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedBy VARCHAR(255),
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (createdBy) REFERENCES users(id),
    FOREIGN KEY (updatedBy) REFERENCES users(id),
    FOREIGN KEY (typeId) REFERENCES content_types(id)
);

-- Contributions Table
CREATE TABLE contributions (
    contentId VARCHAR(255),
    userId VARCHAR(255),
    contributionType ENUM('author', 'editor', 'reviewer'),
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (contentId, userId, contributionType),
    FOREIGN KEY (contentId) REFERENCES content_metadata(contentId),
    FOREIGN KEY (userId) REFERENCES users(id)
);

-- Permissions Table
CREATE TABLE permissions (
    userId VARCHAR(255),
    contentId VARCHAR(255),
    permissionType ENUM('read', 'write', 'manage'),
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (userId, contentId, permissionType),
    FOREIGN KEY (userId) REFERENCES users(id),
    FOREIGN KEY (contentId) REFERENCES content_metadata(contentId)
);