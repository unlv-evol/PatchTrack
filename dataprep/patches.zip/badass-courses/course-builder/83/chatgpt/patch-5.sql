CREATE TABLE content_metadata (
    contentId VARCHAR(255) PRIMARY KEY,
    contentTypeId INT,
    title VARCHAR(255),
    state ENUM('draft', 'published'),
    visibility ENUM('public', 'private', 'unlisted'),
    resources JSON, -- For storing references to other content or resources, with dynamic schemas
    body TEXT, -- Assuming some form of textual content; adjust type as needed
    createdBy VARCHAR(255),
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updatedBy VARCHAR(255),
    updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (createdBy) REFERENCES user(id),
    FOREIGN KEY (updatedBy) REFERENCES user(id),
    FOREIGN KEY (contentTypeId) REFERENCES content_type(id)
);