import React, { useRef } from 'react';
import useOutsideClick from './useOutsideClick';

function MyComponent() {
  const wrapperRef = useRef(null);
  
  const handleOutsideClick = () => {
    console.log('You clicked outside of me!');
  };

  useOutsideClick(wrapperRef, handleOutsideClick);

  return <div ref={wrapperRef}>Click outside of this element</div>;
}