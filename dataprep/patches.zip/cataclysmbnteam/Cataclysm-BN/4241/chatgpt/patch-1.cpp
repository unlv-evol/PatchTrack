class MyClass {
public:
    void myFunction(int x) {
        // function body
    }
};