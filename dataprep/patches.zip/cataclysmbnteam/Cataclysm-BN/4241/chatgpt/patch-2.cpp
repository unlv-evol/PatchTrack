void myFunction(MyClass& obj, int x) {
    // function body
}