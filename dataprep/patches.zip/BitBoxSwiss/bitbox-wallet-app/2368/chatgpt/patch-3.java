goViewModel.getRequestAuth().observe(this, new Observer<Event<Boolean>>() {
       @Override
       public void onChanged(Event<Boolean> requestAuthEvent) {
           Boolean requestAuth = requestAuthEvent.getContentIfNotHandled();
           if (requestAuth != null && requestAuth) {
               Util.log("Requested Auth: " + requestAuth);
               // do something
           }
       }
   });