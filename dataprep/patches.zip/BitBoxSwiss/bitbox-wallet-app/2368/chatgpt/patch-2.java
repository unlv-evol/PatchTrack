private MutableLiveData<Event<Boolean>> requestAuth = new MutableLiveData<>();

   public MutableLiveData<Event<Boolean>> getRequestAuth() {
       return requestAuth;
   }

   public void setRequestAuth(Boolean requestAuth) {
       this.requestAuth.postValue(new Event<>(requestAuth));
   }