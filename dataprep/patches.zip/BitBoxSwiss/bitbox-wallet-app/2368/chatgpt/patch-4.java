public class AuthRequestEvent {
       private boolean hasBeenHandled = false;

       public boolean isHandled() {
           return hasBeenHandled;
       }

       public void markAsHandled() {
           this.hasBeenHandled = true;
       }
   }