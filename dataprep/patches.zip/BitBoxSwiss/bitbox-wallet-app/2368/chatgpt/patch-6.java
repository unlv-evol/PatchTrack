goViewModel.getRequestAuthEvent().observe(this, new Observer<AuthRequestEvent>() {
       @Override
       public void onChanged(AuthRequestEvent event) {
           if (event != null && !event.isHandled()) {
               Util.log("Authentication Requested");
               event.markAsHandled();
               // Handle auth request
           }
       }
   });