type MyType = { something: string } | null;

let myArray: MyType[] = [ { something: "hello" }, null, { something: "world" }, null ];

function isNotNull<T>(value: T | null): value is T {
    return value !== null;
}

let filteredArray: { something: string }[] = myArray.filter(isNotNull);
