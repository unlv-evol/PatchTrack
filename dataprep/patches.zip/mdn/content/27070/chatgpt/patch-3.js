app.on('issue_comment.created', async (context) => {
  const { comment, issue, repository } = context.payload;

  if (issue.pull_request && comment.body.trim() === '/format') {
    const { head } = issue.pull_request;
    const cloneUrl = repository.clone_url;
    const branchName = head.ref;

    // Clone the repository
    exec(`git clone ${cloneUrl}`, (err, stdout, stderr) => {
      if (err) {
        console.error(err);
        return;
      }

      // Change to the cloned repository's directory
      const repoDir = `${branchName}`;
      process.chdir(repoDir);

      // Checkout the PR branch
      exec(`git checkout ${branchName}`, (err, stdout, stderr) => {
        if (err) {
          console.error(err);
          return;
        }

        // Run prettier
        exec('prettier -w', (err, stdout, stderr) => {
          if (err) {
            console.error(err);
            return;
          }

          // Commit and push the changes
          exec('git commit -a -m "Format code"', (err, stdout, stderr) => {
            if (err) {
              console.error(err);
              return;
            }

            exec(`git push origin ${branchName}`, (err, stdout, stderr) => {
              if (err) {
                console.error(err);
                return;
              }

              console.log('Code formatted and pushed.');
            });
          });
        });
      });
    });
  }
});
