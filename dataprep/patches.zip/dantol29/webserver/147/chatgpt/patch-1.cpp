HTTPResponse response = CGIStringToResponse(cgiOutput);
    return response;