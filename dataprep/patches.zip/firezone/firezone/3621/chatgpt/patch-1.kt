class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        // Perform the sign-in action or prompt for sign-in

        // Stop the foreground service
        context?.stopService(Intent(context, YourForegroundService::class.java))
    }
}

private fun configIntent(): PendingIntent {
    val intent = Intent(this, NotificationActionReceiver::class.java)
    // You can also add extras to the intent if needed

    return PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
}