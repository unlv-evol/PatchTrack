// User model representing a user entity
class User {
    public $id;
    public $username;
    public $email;

    // Additional properties and methods can be added as needed
}

// UserRepository interface defining the contract for data access
interface UserRepositoryInterface {
    public function getById($id);
    public function getByUsername($username);
    public function save(User $user);
    public function update(User $user);
    public function delete(User $user);
}

// UserRepository implementing the Repository Pattern
class UserRepository implements UserRepositoryInterface {
    private $db;

    public function __construct(PDO $db) {
        $this->db = $db;
    }

    public function getById($id) {
        // Logic to fetch a user by ID from the database
    }

    public function getByUsername($username) {
        // Logic to fetch a user by username from the database
    }

    public function save(User $user) {
        // Logic to save a new user to the database
    }

    public function update(User $user) {
        // Logic to update an existing user in the database
    }

    public function delete(User $user) {
        // Logic to delete a user from the database
    }
}

// Example of how the UserRepository might be used in your application
$db = new PDO('mysql:host=localhost;dbname=mydatabase', 'username', 'password');
$userRepository = new UserRepository($db);

// Example of fetching a user by ID
$user = $userRepository->getById(1);

// Example of saving a new user
$newUser = new User();
$newUser->username = 'john_doe';
$newUser->email = 'john@example.com';
$userRepository->save($newUser);

// Example of updating an existing user
$userToUpdate = $userRepository->getById(2);
$userToUpdate->email = 'updated_email@example.com';
$userRepository->update($userToUpdate);

// Example of deleting a user
$userToDelete = $userRepository->getById(3);
$userRepository->delete($userToDelete);