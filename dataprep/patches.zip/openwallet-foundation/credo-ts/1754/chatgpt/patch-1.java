class Animal {
       void makeSound() {
           System.out.println("Some generic sound");
       }
   }

   class Cat extends Animal {
       @Override
       void makeSound() {
           System.out.println("Meow");
       }
   }