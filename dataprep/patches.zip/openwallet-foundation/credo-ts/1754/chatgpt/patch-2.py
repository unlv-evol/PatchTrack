# Example of overwriting a file in Python
   with open('example.txt', 'w') as file:
       file.write('This will overwrite the existing content.')