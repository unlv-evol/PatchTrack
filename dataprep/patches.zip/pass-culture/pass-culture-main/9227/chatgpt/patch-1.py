from typing import List

class StockCreationBodyModel(BaseModel):
    # ... [rest of your model definition]

def _fetch_existing_stocks(offer_id: int, stocks_payload: List[serialization.StockCreationBodyModel]) -> List[offers_models.Stock]:
    criteria = [
        offers_models.Stock.offerId == offer_id,
        offers_models.Stock.isSoftDeleted == False,
    ]
    # Create tuples of attributes to filter
    stock_attributes = [(stock.price or decimal.Decimal(0), 
                         stock.beginning_datetime, 
                         stock.booking_limit_datetime, 
                         stock.price_category_id, 
                         stock.quantity) for stock in stocks_payload]

    # Add criteria for each stock attribute
    for price, beginning, booking_limit, price_category_id, quantity in stock_attributes:
        criteria.append(
            (offers_models.Stock.price == price) &
            (offers_models.Stock.beginningDatetime == beginning) &
            (offers_models.Stock.bookingLimitDatetime == booking_limit) &
            (offers_models.Stock.priceCategoryId == price_category_id) &
            (offers_models.Stock.quantity == quantity)
        )

    # Perform a single query to fetch all stocks that match any of the criteria
    return offers_models.Stock.query.filter(or_(*criteria)).all()

def _stock_exists(existing_stocks, stock_payload) -> bool:
    for stock in existing_stocks:
        if (stock.offerId == stock_payload.offer_id and
            stock.price == (stock_payload.price or decimal.Decimal(0)) and
            stock.beginningDatetime == stock_payload.beginning_datetime and
            stock.bookingLimitDatetime == stock_payload.booking_limit_datetime and
            stock.priceCategoryId == stock_payload.price_category_id and
            stock.quantity == stock_payload.quantity):
            return True
    return False

# ...
existing_stocks = _fetch_existing_stocks(body.offer_id, stocks_to_create)

for stock_to_create in stocks_to_create:
    if not _stock_exists(existing_stocks, stock_to_create):
        # ...