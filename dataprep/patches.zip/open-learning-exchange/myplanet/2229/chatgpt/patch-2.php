<string-array name="language">
    <item>Anglais</item>
    <item>नेपाली</item>
    <item>Français</item>
    <item>Espagnol</item>
    <item>عربى</item>
    <item>Somali</item>
</string-array>

<string-array name="language_keys">
    <item>en</item>
    <item>ne</item>
    <item>fr</item>
    <item>es</item>
    <item>ar</item>
    <item>so</item>
</string-array>

<string-array name="info_type">
    <item>Langues</item>
    <item>Éducation</item>
    <item>Parcours professionnel</item>
    <item>Insignes</item>
    <item>Certificats</item>
    <item>Stages</item>
    <item>Distinctions</item>
</string-array>
<string-array name="open_With">
    <item>HTML</item>
    <item>PDF.js</item>
    <item>BeLL-Reader</item>
    <item>Mp3</item>
    <item>Lecteur vidéo Flow</item>
    <item>Lecteur de livres vidéo BeLL</item>
    <item>Vidéo native</item>
</string-array>
<string-array name="media">
    <item>Texte</item>
    <item>Graphique/Photos</item>
    <item>Audio/Musique/Livre</item>
    <item>Vidéo</item>
</string-array>

<string-array name="resource_type">
    <item>Manuel scolaire</item>
    <item>Plan de cours</item>
    <item>Activités</item>
    <item>Exercices</item>
    <item>Questions de discussion</item>
</string-array>

<string-array name="array_levels">
    <item>Éducation précoce</item>
    <item>École primaire inférieure</item>
    <item>École primaire supérieure</item>
    <item>Cycle inférieur du secondaire</item>
    <item>Cycle supérieur du secondaire</item>
    <item>Études de premier cycle</item>
    <item>Études supérieures</item>
    <item>Professionnel</item>
</string-array>
<string-array name="array_subjects">
    <item>Agriculture</item>
    <item>Arts</item>
    <item>Business et Finance</item>
    <item>Environnement</item>
    <item>Alimentation et Nutrition</item>
    <item>Géographie</item>
    <item>Santé et Médecine</item>
    <item>Histoire</item>
    <item>Développement humain</item>
    <item>Langues</item>
    <item>Droit</item>
    <item>Apprentissage</item>
</string-array>
<string-array name="array_resource_for">
    <item>Par défaut</item>
    <item>Leader</item>
    <item>Apprenant</item>
</string-array>
