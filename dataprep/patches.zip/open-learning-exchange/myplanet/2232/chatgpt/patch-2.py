string = "Hello, 世界!"
arabic_string = string.encode('utf-8').decode('utf-8')

print(arabic_string)
