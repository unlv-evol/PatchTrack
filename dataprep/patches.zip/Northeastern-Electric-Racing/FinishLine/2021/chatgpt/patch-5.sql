UPDATE employees
SET department = 'Sales'
WHERE last_name = 'Smith';