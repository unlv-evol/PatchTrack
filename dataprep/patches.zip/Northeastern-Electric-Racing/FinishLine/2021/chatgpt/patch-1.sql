ALTER TABLE table_name
ADD column_name data_type [constraints];