WITH CTE AS (
    SELECT 
        "reimbursementRequestId",
        ROW_NUMBER() OVER (ORDER BY "dateCreated") AS new_identifier
    FROM 
        "Reimbursement_Request"
    WHERE
        "identifier" IS NULL
)
UPDATE "Reimbursement_Request" AS rr
SET "identifier" = cte.new_identifier
FROM CTE
WHERE rr."reimbursementRequestId" = CTE."reimbursementRequestId";