UPDATE employees
SET department = 'IT';