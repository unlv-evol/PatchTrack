-- Update the employees table
UPDATE employees
SET department_name = 'Sales'
WHERE employee_id = 123;

-- Update the departments table
UPDATE departments
SET department_description = 'Sales Department'
WHERE department_name = 'Sales';