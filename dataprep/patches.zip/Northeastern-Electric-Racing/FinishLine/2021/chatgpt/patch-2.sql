ALTER TABLE employees
ADD department VARCHAR(50);