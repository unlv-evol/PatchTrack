// Global patterns stored to avoid recompilation on each function call.
var patterns = []*regexp.Regexp{
	regexp.MustCompile(`"code"\s*:\s*(\d+)`),       // Matches `"code": 4XX`
	regexp.MustCompile(`(\d+)\s+Not Found`),        // Matches `404 Not Found`
	regexp.MustCompile(`(\d+)\s+page not found`),   // Matches `404 page not found`
	regexp.MustCompile(`HTTP\/\d\.\d\s+(\d+)`),     // Matches HTTP status codes like `HTTP/1.1 404`
	regexp.MustCompile(`"statusCode"\s*:\s*(\d+)`), // Matches `"statusCode": 4XX`
}

// extractStatusFromResponse returns a status code extracted from the response string.
// If no status code is found, it returns "unknown" to indicate unclear status.
func extractStatusFromResponse(response string) string {
	for _, pattern := range patterns {
		matches := pattern.FindStringSubmatch(response)
		if len(matches) > 1 {
			return matches[1] // Return the first captured group, which should be the status code.
		}
	}
	return "unknown" // Changed from "200" to "unknown" to avoid implying success when uncertain.
}