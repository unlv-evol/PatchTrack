using System.IO;
using System.Text.Json;
using Xunit;

public class MyTestData
{
    public string Property1 { get; set; }
    public int Property2 { get; set; }
}

public class MyTests
{
    [Fact]
    public void TestUsingJsonData()
    {
        // Assuming the JSON file is named "testData.json" and is located in the root of the test project
        string jsonString = File.ReadAllText("testData.json");

        // Deserialize the JSON string into the MyTestData object
        MyTestData testData = JsonSerializer.Deserialize<MyTestData>(jsonString);

        // Use the testData in your test
        // ... your test logic here ...
    }
}