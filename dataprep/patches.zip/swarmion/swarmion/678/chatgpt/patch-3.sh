./release.sh premajor 2.0.0-alpha.1
