rep_tunes = RepertoireTune.objects.filter(player=user).select_related('tune')
tunes = [tune.tune for tune in rep_tunes]