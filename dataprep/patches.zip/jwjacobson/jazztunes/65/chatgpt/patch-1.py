rep_tunes = RepertoireTune.objects.filter(player=user)
tunes = [tune.tune for tune in rep_tunes]