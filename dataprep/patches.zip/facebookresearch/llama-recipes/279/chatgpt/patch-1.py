import requests

# Define the URL and payload
url = "http://localhost:5000/generate"
data = {
    "prompt": "Who wrote the book Innovators dilemma?",
    "max_tokens": 300,
    "temperature": 0
}

# Send the POST request
response = requests.post(url, json=data)

# Check the response status code
if response.status_code == 200:
    # Print the response content
    print(response.text)
else:
    print(f"Request failed with status code {response.status_code}")