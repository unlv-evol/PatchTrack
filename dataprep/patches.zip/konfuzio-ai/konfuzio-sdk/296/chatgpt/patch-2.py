build_categorization_ai_pipeline(ImageModule='ModelA', TextModule='ModelB')
